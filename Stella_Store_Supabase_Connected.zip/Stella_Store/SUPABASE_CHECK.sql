-- Run this in Supabase SQL Editor if the browser login gets an RPC permission error.
GRANT EXECUTE ON FUNCTION public.is_store_admin() TO authenticated;

-- Optional: confirm your admin registration (replace with your Supabase Auth email)
SELECT u.email, a.user_id
FROM auth.users AS u
JOIN public.store_admins AS a ON a.user_id = u.id;
